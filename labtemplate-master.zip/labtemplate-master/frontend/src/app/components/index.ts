export * from './pages/home/home.component';

